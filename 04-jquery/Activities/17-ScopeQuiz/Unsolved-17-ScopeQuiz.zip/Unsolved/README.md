# Scope Quiz

## File

* [`scope-quiz-unsolved`](Unsolved/scope-quiz-unsolved.html)

## Instructions

* Spend a few moments studying the code with the person sitting next to you.

* Then run the program in the browser.

* Once you run the program, you'll find that Code Block 1 leads to different alerts than Code Block 2.

* Ask your partner which Code Block is behaving the way you would expect.

* Then work with your partner to try and identify the specific difference that is causing the issue with the faulty block.

* Once you spot the issue, try to explain to your partner why JavaScript is handling these Code Blocks differently.
