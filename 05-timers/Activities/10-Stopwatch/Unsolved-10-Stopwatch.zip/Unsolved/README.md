# Stopwatch

## File

* [`stopwatch`](Unsolved/stopwatch.js)

## Instructions

* Open stopwatch.js and follow the instructions in the file.

* You will not not need to edit the HTML file we give you.

* Use jQuery and the timing events you learned today to create a stopwatch with Start, Stop and Reset buttons.

* **BONUS:** Add a lap timer.

* **BONUS:** Use CSS to style the timer
