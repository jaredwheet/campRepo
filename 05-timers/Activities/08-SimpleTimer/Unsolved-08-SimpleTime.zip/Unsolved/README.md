# Simple Timer

## File

* [`simple-timer`](Unsolved/simple-timer.html)

## Instructions

* Make a page with a simple timer that sends an alert and plays a sound after 15 seconds.

* Have it send an alert when 5 seconds has passed, 10 seconds has passed and when the time is up.

* You will use this to time the break!
